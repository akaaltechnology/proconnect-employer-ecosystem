import { NextResponse } from 'next/server';
import { GeoFenceValidator } from '@proconnect/shared';

// Simulated DB of shifts with coordinates
const mockShiftsDB: Record<string, {
  id: string;
  title: string;
  latitude: number;
  longitude: number;
  radiusMeters: number;
}> = {
  "shift-100": {
    id: "shift-100",
    title: "Morning Warehouse Shift - Vancouver HQ",
    latitude: 49.2827, // Vancouver Lat
    longitude: -123.1207, // Vancouver Lng
    radiusMeters: 200, // 200 meters geofence
  },
  "shift-200": {
    id: "shift-200",
    title: "Construction Site B - Calgary",
    latitude: 51.0447, // Calgary Lat
    longitude: -114.0719, // Calgary Lng
    radiusMeters: 500, // 500 meters geofence
  }
};

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { employeeId, shiftId, latitude, longitude } = body;

    if (!employeeId || !shiftId || typeof latitude !== 'number' || typeof longitude !== 'number') {
      return NextResponse.json(
        { error: 'Invalid parameters. Required: employeeId (string), shiftId (string), latitude (number), longitude (number).' },
        { status: 400 }
      );
    }

    const shift = mockShiftsDB[shiftId];
    if (!shift) {
      return NextResponse.json({ error: 'Shift not found.' }, { status: 404 });
    }

    const validation = GeoFenceValidator.validate(
      { latitude, longitude },
      { latitude: shift.latitude, longitude: shift.longitude },
      shift.radiusMeters
    );

    return NextResponse.json({
      success: true,
      shiftTitle: shift.title,
      employeeId,
      shiftId,
      latitude,
      longitude,
      validation,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
