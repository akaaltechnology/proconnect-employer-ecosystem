export interface ReviewData {
  id: string;
  contractId: string;
  authorId: string;
  targetId: string;
  rating: number;
  comment?: string;
  isRevealed: boolean;
  createdAt: Date;
  revealedAt?: Date;
}

export class ReviewEngine {
  private static readonly GRACE_PERIOD_MS = 14 * 24 * 60 * 60 * 1000; // 14 days

  /**
   * Processes a newly submitted review and determines if the privacy lock should be released.
   * If both parties have submitted reviews for the contract, or if the grace period has elapsed
   * for the first review, both reviews should be revealed.
   * 
   * Returns the list of reviews that need to be updated to 'revealed = true'.
   */
  public static processReviewSubmission(
    newReview: ReviewData,
    existingReviewsForContract: ReviewData[],
    now: Date = new Date()
  ): {
    reviewsToReveal: string[]; // List of Review IDs to set isRevealed = true
    shouldRevealNew: boolean;
  } {
    // Filter existing reviews for this specific contract
    const contractReviews = [...existingReviewsForContract, newReview];

    // Find the review by the counter-party
    const counterPartyReview = existingReviewsForContract.find(
      (r) => r.contractId === newReview.contractId && r.authorId === newReview.targetId
    );

    if (counterPartyReview) {
      // Both parties have submitted! Reveal both reviews immediately.
      return {
        reviewsToReveal: [newReview.id, counterPartyReview.id],
        shouldRevealNew: true,
      };
    }

    // If only one review exists (the new one), check if a historic one is timed out (should not happen for a new review, 
    // but check for scheduled jobs resolving old reviews).
    const timedOutReviews: string[] = [];
    let shouldRevealNew = false;

    for (const r of contractReviews) {
      const elapsed = now.getTime() - r.createdAt.getTime();
      if (elapsed >= this.GRACE_PERIOD_MS) {
        timedOutReviews.push(r.id);
        if (r.id === newReview.id) {
          shouldRevealNew = true;
        }
      }
    }

    return {
      reviewsToReveal: timedOutReviews,
      shouldRevealNew,
    };
  }

  /**
   * Utility to filter out unrevealed reviews when querying a user's profile.
   * This guarantees that a freelancer or employer cannot see reviews written about them
   * until they have completed their half of the review or the grace period has elapsed.
   */
  public static filterVisibleReviews(reviews: ReviewData[]): ReviewData[] {
    return reviews.filter((r) => r.isRevealed);
  }
}
