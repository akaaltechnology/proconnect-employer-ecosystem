import { NextResponse } from 'next/server';
import { EscrowStateMachine, EscrowState } from '@proconnect/shared';
// In production, we import the real prisma client:
// import { prisma } from '@proconnect/database';

// Mock DB store for demonstration/scaffolding
const mockEscrowDB: Record<string, {
  id: string;
  totalAmount: number;
  remainingAmount: number;
  freelancerId: string;
  clientId: string;
  state: EscrowState;
}> = {
  "escrow-1": {
    id: "escrow-1",
    totalAmount: 1000,
    remainingAmount: 1000,
    freelancerId: "free-123",
    clientId: "client-456",
    state: "CREATED",
  }
};

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');

  if (!id || !mockEscrowDB[id]) {
    return NextResponse.json({ error: 'Escrow contract not found' }, { status: 404 });
  }

  const data = mockEscrowDB[id];
  const fsm = new EscrowStateMachine(data.state, {
    id: data.id,
    totalAmount: data.totalAmount,
    remainingAmount: data.remainingAmount,
    freelancerId: data.freelancerId,
    clientId: data.clientId,
  });

  return NextResponse.json({
    id: data.id,
    state: fsm.getState(),
    context: fsm.getContext(),
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, id, amount, nextState } = body;

    if (!id || !mockEscrowDB[id]) {
      return NextResponse.json({ error: 'Escrow contract not found' }, { status: 404 });
    }

    const data = mockEscrowDB[id];
    const fsm = new EscrowStateMachine(data.state, {
      id: data.id,
      totalAmount: data.totalAmount,
      remainingAmount: data.remainingAmount,
      freelancerId: data.freelancerId,
      clientId: data.clientId,
    });

    if (action === 'transition') {
      if (!nextState) {
        return NextResponse.json({ error: 'nextState is required for transition action' }, { status: 400 });
      }
      fsm.transitionTo(nextState as EscrowState);
      data.state = fsm.getState();
    } else if (action === 'release') {
      if (typeof amount !== 'number') {
        return NextResponse.json({ error: 'amount is required and must be a number' }, { status: 400 });
      }
      fsm.releaseFunds(amount);
      data.remainingAmount = fsm.getContext().remainingAmount;
      data.state = fsm.getState();
    } else if (action === 'dispute') {
      fsm.fileDispute();
      data.state = fsm.getState();
    } else if (action === 'resolve_dispute') {
      const { freelancerPayout, clientRefund } = body;
      if (typeof freelancerPayout !== 'number' || typeof clientRefund !== 'number') {
        return NextResponse.json({ error: 'freelancerPayout and clientRefund are required numbers' }, { status: 400 });
      }
      fsm.resolveDispute(freelancerPayout, clientRefund);
      data.remainingAmount = fsm.getContext().remainingAmount;
      data.state = fsm.getState();
    } else {
      return NextResponse.json({ error: 'Unsupported action' }, { status: 400 });
    }

    // Save back to DB (simulated)
    mockEscrowDB[id] = data;

    // Log the transaction or update audit trail in production:
    // await prisma.auditLog.create({ data: { action: `ESCROW_${action.toUpperCase()}`, details: JSON.stringify(data) } });

    return NextResponse.json({
      success: true,
      id: data.id,
      state: data.state,
      remainingAmount: data.remainingAmount,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
