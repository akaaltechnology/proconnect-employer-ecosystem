/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ["@proconnect/shared", "@proconnect/database"],
};

export default nextConfig;
