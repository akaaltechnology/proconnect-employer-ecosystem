export interface PayrollCalculationInput {
  grossEarnings: number; // For the current period
  ytdEarnings: number;    // Year-to-date earnings prior to this period
  province: string;       // e.g. "ON", "QC", "BC", "AB"
  payPeriodsPerYear: number; // e.g., 26 for bi-weekly, 12 for monthly
}

export interface PayrollCalculationResult {
  grossEarnings: number;
  cppDeduction: number;
  eiDeduction: number;
  qpipDeduction: number; // Quebec Parental Insurance Plan
  federalTax: number;
  provincialTax: number;
  quebecLaw25Deduction: number; // Simulated Quebec Privacy Consent Admin fee if applicable
  totalDeductions: number;
  netPay: number;
}

export class CanadianTaxCalculator {
  // Statutory limits (2026 approximation)
  private static readonly CPP_RATE = 0.0595;
  private static readonly CPP_EXEMPTION_ANNUAL = 3500;
  private static readonly CPP_MAX_EARNINGS = 68500;

  private static readonly QPP_RATE = 0.0640;
  private static readonly QPP_EXEMPTION_ANNUAL = 3500;
  private static readonly QPP_MAX_EARNINGS = 68500;

  private static readonly EI_STANDARD_RATE = 0.0166;
  private static readonly EI_QC_RATE = 0.0132;
  private static readonly EI_MAX_EARNINGS = 63200;

  private static readonly QPIP_RATE = 0.00494; // QPIP employee rate
  private static readonly QPIP_MAX_EARNINGS = 94000;

  // Progressive Tax Bracket definition structure
  private static readonly FED_BRACKETS = [
    { limit: 55867, rate: 0.15 },
    { limit: 111733, rate: 0.205 },
    { limit: 173205, rate: 0.26 },
    { limit: 246752, rate: 0.29 },
    { limit: Infinity, rate: 0.33 },
  ];

  private static readonly PROV_BRACKETS: Record<string, { limit: number; rate: number }[]> = {
    ON: [
      { limit: 51446, rate: 0.0505 },
      { limit: 102894, rate: 0.0915 },
      { limit: 150000, rate: 0.1116 },
      { limit: 220000, rate: 0.1216 },
      { limit: Infinity, rate: 0.1316 },
    ],
    QC: [
      { limit: 51780, rate: 0.14 },
      { limit: 103545, rate: 0.19 },
      { limit: 126000, rate: 0.24 },
      { limit: Infinity, rate: 0.2575 },
    ],
    BC: [
      { limit: 47937, rate: 0.0506 },
      { limit: 95875, rate: 0.0770 },
      { limit: 110076, rate: 0.1050 },
      { limit: Infinity, rate: 0.1229 },
    ],
    AB: [
      { limit: 142292, rate: 0.10 },
      { limit: 170751, rate: 0.12 },
      { limit: Infinity, rate: 0.13 },
    ],
  };

  /**
   * Calculates deductions for a pay period based on YTD earnings and province.
   */
  public static calculatePayPeriod(input: PayrollCalculationInput): PayrollCalculationResult {
    const { grossEarnings, ytdEarnings, province, payPeriodsPerYear } = input;

    const isQC = province.toUpperCase() === 'QC';
    
    // 1. CPP / QPP Calculation
    let cppDeduction = 0;
    const cppExemptionPerPeriod = this.CPP_EXEMPTION_ANNUAL / payPeriodsPerYear;
    
    if (isQC) {
      // QPP
      const maxRemainingQppEarnings = Math.max(0, this.QPP_MAX_EARNINGS - ytdEarnings);
      const subjectEarnings = Math.max(0, Math.min(grossEarnings, maxRemainingQppEarnings) - cppExemptionPerPeriod);
      cppDeduction = subjectEarnings * this.QPP_RATE;
    } else {
      // CPP
      const maxRemainingCppEarnings = Math.max(0, this.CPP_MAX_EARNINGS - ytdEarnings);
      const subjectEarnings = Math.max(0, Math.min(grossEarnings, maxRemainingCppEarnings) - cppExemptionPerPeriod);
      cppDeduction = subjectEarnings * this.CPP_RATE;
    }

    // 2. EI Calculation
    const maxRemainingEiEarnings = Math.max(0, this.EI_MAX_EARNINGS - ytdEarnings);
    const subjectEiEarnings = Math.min(grossEarnings, maxRemainingEiEarnings);
    const eiRate = isQC ? this.EI_QC_RATE : this.EI_STANDARD_RATE;
    const eiDeduction = subjectEiEarnings * eiRate;

    // 3. QPIP (Quebec Parental Insurance Plan) Calculation
    let qpipDeduction = 0;
    if (isQC) {
      const maxRemainingQpipEarnings = Math.max(0, this.QPIP_MAX_EARNINGS - ytdEarnings);
      const subjectQpipEarnings = Math.min(grossEarnings, maxRemainingQpipEarnings);
      qpipDeduction = subjectQpipEarnings * this.QPIP_RATE;
    }

    // 4. Income Tax Calculations (Annualized Method)
    const annualizedGross = (ytdEarnings + grossEarnings) * (payPeriodsPerYear / (payPeriodsPerYear - (ytdEarnings / grossEarnings || 0)));
    // For simplicity, we approximate annualization by multiplying current period gross bypayPeriodsPerYear
    const simulatedAnnualGross = grossEarnings * payPeriodsPerYear;

    const annualFedTax = this.calculateProgressiveTax(simulatedAnnualGross, this.FED_BRACKETS);
    const fedTaxPeriod = annualFedTax / payPeriodsPerYear;

    const provBrackets = this.PROV_BRACKETS[province.toUpperCase()] || this.PROV_BRACKETS['ON']; // Fallback ON
    const annualProvTax = this.calculateProgressiveTax(simulatedAnnualGross, provBrackets);
    const provTaxPeriod = annualProvTax / payPeriodsPerYear;

    // 5. Law 25 compliance administrative offset for Quebec employees (simulated requirement check)
    // Law 25 mandates enhanced data sovereignty and consent trackers. Some companies allocate a small payroll compliance tracking offset.
    const quebecLaw25Deduction = isQC ? 1.50 : 0.00; // flat $1.50 compliance charge per period

    const totalDeductions = cppDeduction + eiDeduction + qpipDeduction + fedTaxPeriod + provTaxPeriod + quebecLaw25Deduction;
    const netPay = Math.max(0, grossEarnings - totalDeductions);

    return {
      grossEarnings,
      cppDeduction: this.round(cppDeduction),
      eiDeduction: this.round(eiDeduction),
      qpipDeduction: this.round(qpipDeduction),
      federalTax: this.round(fedTaxPeriod),
      provincialTax: this.round(provTaxPeriod),
      quebecLaw25Deduction: this.round(quebecLaw25Deduction),
      totalDeductions: this.round(totalDeductions),
      netPay: this.round(netPay),
    };
  }

  /**
   * Helper to compute tax on progressive brackets.
   */
  private static calculateProgressiveTax(income: number, brackets: { limit: number; rate: number }[]): number {
    let tax = 0;
    let previousLimit = 0;

    for (const bracket of brackets) {
      if (income > bracket.limit) {
        tax += (bracket.limit - previousLimit) * bracket.rate;
        previousLimit = bracket.limit;
      } else {
        tax += (income - previousLimit) * bracket.rate;
        break;
      }
    }

    return tax;
  }

  private static round(val: number): number {
    return Math.round((val + Number.EPSILON) * 100) / 100;
  }
}
