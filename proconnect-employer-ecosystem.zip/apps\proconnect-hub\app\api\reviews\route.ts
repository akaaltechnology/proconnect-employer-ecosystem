import { NextResponse } from 'next/server';
import { ReviewEngine, ReviewData } from '@proconnect/shared';

// Simulated DB of reviews
const mockReviewsDB: ReviewData[] = [
  {
    id: "rev-1",
    contractId: "contract-abc",
    authorId: "client-456",
    targetId: "free-123",
    rating: 5,
    comment: "Excellent work!",
    isRevealed: false,
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
  }
];

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const targetId = searchParams.get('targetId');

  if (!targetId) {
    return NextResponse.json({ error: 'targetId query parameter is required' }, { status: 400 });
  }

  // Filter reviews for this target
  const targetReviews = mockReviewsDB.filter((r) => r.targetId === targetId);
  // Apply the dual-sided review privacy filter
  const visibleReviews = ReviewEngine.filterVisibleReviews(targetReviews);

  return NextResponse.json({
    reviews: visibleReviews,
    totalCount: visibleReviews.length,
    hiddenCount: targetReviews.length - visibleReviews.length,
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { contractId, authorId, targetId, rating, comment } = body;

    if (!contractId || !authorId || !targetId || typeof rating !== 'number') {
      return NextResponse.json({ error: 'contractId, authorId, targetId, and rating are required fields' }, { status: 400 });
    }

    // Check if author already submitted a review for this contract
    const alreadyExists = mockReviewsDB.some(
      (r) => r.contractId === contractId && r.authorId === authorId
    );
    if (alreadyExists) {
      return NextResponse.json({ error: 'You have already submitted a review for this contract.' }, { status: 400 });
    }

    const newReview: ReviewData = {
      id: `rev-${Math.random().toString(36).substr(2, 9)}`,
      contractId,
      authorId,
      targetId,
      rating,
      comment,
      isRevealed: false,
      createdAt: new Date(),
    };

    // Retrieve other reviews for this contract to check if we can reveal
    const contractReviews = mockReviewsDB.filter((r) => r.contractId === contractId);

    const { reviewsToReveal, shouldRevealNew } = ReviewEngine.processReviewSubmission(
      newReview,
      contractReviews
    );

    newReview.isRevealed = shouldRevealNew;
    if (shouldRevealNew) {
      newReview.revealedAt = new Date();
    }

    // Reveal existing counter-party reviews if triggered
    mockReviewsDB.forEach((r) => {
      if (reviewsToReveal.includes(r.id)) {
        r.isRevealed = true;
        r.revealedAt = new Date();
      }
    });

    mockReviewsDB.push(newReview);

    return NextResponse.json({
      success: true,
      review: newReview,
      revealedPartners: reviewsToReveal.filter(id => id !== newReview.id),
      isRevealedImmediately: newReview.isRevealed,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
