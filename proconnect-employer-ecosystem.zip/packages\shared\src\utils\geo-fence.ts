export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface GeofenceValidationResult {
  distanceMeters: number;
  isWithin: boolean;
  radiusMeters: number;
}

export class GeoFenceValidator {
  private static readonly EARTH_RADIUS_METERS = 6371000;

  /**
   * Validates if a worker's GPS coordinate falls within a specified radius of a job site coordinate.
   * Uses the Haversine formula for spherical distance calculations.
   */
  public static validate(
    worker: Coordinates,
    site: Coordinates,
    radiusMeters: number
  ): GeofenceValidationResult {
    const lat1Rad = this.toRadians(worker.latitude);
    const lat2Rad = this.toRadians(site.latitude);
    const deltaLatRad = this.toRadians(site.latitude - worker.latitude);
    const deltaLngRad = this.toRadians(site.longitude - worker.longitude);

    // Haversine formula
    const a =
      Math.sin(deltaLatRad / 2) * Math.sin(deltaLatRad / 2) +
      Math.cos(lat1Rad) *
        Math.cos(lat2Rad) *
        Math.sin(deltaLngRad / 2) *
        Math.sin(deltaLngRad / 2);

    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const distanceMeters = this.EARTH_RADIUS_METERS * c;

    return {
      distanceMeters: Math.round(distanceMeters * 100) / 100,
      isWithin: distanceMeters <= radiusMeters,
      radiusMeters,
    };
  }

  private static toRadians(degrees: number): number {
    return (degrees * Math.PI) / 180;
  }
}
