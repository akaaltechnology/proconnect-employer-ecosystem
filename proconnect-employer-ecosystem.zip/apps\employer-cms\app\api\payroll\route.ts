import { NextResponse } from 'next/server';
import { CanadianTaxCalculator } from '@proconnect/shared';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { grossEarnings, ytdEarnings, province, payPeriodsPerYear } = body;

    // Validation
    if (
      typeof grossEarnings !== 'number' ||
      typeof ytdEarnings !== 'number' ||
      !province ||
      typeof payPeriodsPerYear !== 'number'
    ) {
      return NextResponse.json(
        { error: 'Invalid parameters. Required: grossEarnings (number), ytdEarnings (number), province (string), payPeriodsPerYear (number).' },
        { status: 400 }
      );
    }

    const calculations = CanadianTaxCalculator.calculatePayPeriod({
      grossEarnings,
      ytdEarnings,
      province,
      payPeriodsPerYear,
    });

    return NextResponse.json({
      success: true,
      data: calculations,
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
