import { EscrowStateMachine, EscrowState } from '../utils/escrow-state';
import { CanadianTaxCalculator } from '../utils/tax-calculator';
import { GeoFenceValidator } from '../utils/geo-fence';
import { ReviewEngine, ReviewData } from '../utils/review-engine';

describe('Escrow State Machine', () => {
  it('should flow through standard lifecycle CREATED -> FUNDED -> RELEASED', () => {
    const fsm = new EscrowStateMachine('CREATED', {
      id: 'esc-1',
      totalAmount: 1000,
      remainingAmount: 1000,
      freelancerId: 'free-1',
      clientId: 'client-1',
    });

    expect(fsm.getState()).toBe('CREATED');
    expect(fsm.canTransitionTo('FUNDED')).toBe(true);
    expect(fsm.canTransitionTo('RELEASED')).toBe(false);

    fsm.transitionTo('FUNDED');
    expect(fsm.getState()).toBe('FUNDED');

    fsm.releaseFunds(1000);
    expect(fsm.getState()).toBe('RELEASED');
    expect(fsm.getContext().remainingAmount).toBe(0);
  });

  it('should block invalid transitions', () => {
    const fsm = new EscrowStateMachine('CREATED', {
      id: 'esc-2',
      totalAmount: 500,
      remainingAmount: 500,
      freelancerId: 'free-1',
      clientId: 'client-1',
    });

    expect(() => fsm.transitionTo('RELEASED')).toThrow();
  });

  it('should transition to DISPUTED and resolve with custom splits', () => {
    const fsm = new EscrowStateMachine('FUNDED', {
      id: 'esc-3',
      totalAmount: 1000,
      remainingAmount: 1000,
      freelancerId: 'free-1',
      clientId: 'client-1',
    });

    fsm.fileDispute();
    expect(fsm.getState()).toBe('DISPUTED');

    const split = fsm.resolveDispute(600, 400);
    expect(fsm.getState()).toBe('RESOLVED');
    expect(split.freelancerPayout).toBe(600);
    expect(split.clientRefund).toBe(400);
  });
});

describe('Canadian Tax Calculator', () => {
  it('should calculate ON tax deductions correctly', () => {
    const result = CanadianTaxCalculator.calculatePayPeriod({
      grossEarnings: 3000,
      ytdEarnings: 15000,
      province: 'ON',
      payPeriodsPerYear: 26,
    });

    expect(result.grossEarnings).toBe(3000);
    expect(result.cppDeduction).toBeGreaterThan(0);
    expect(result.eiDeduction).toBeGreaterThan(0);
    expect(result.federalTax).toBeGreaterThan(0);
    expect(result.provincialTax).toBeGreaterThan(0);
    expect(result.qpipDeduction).toBe(0);
    expect(result.quebecLaw25Deduction).toBe(0);
    expect(result.netPay).toBeLessThan(3000);
  });

  it('should include Quebec-specific deductions (QPIP, Law 25 flat charge) for QC province', () => {
    const result = CanadianTaxCalculator.calculatePayPeriod({
      grossEarnings: 3000,
      ytdEarnings: 15000,
      province: 'QC',
      payPeriodsPerYear: 26,
    });

    expect(result.qpipDeduction).toBeGreaterThan(0);
    expect(result.quebecLaw25Deduction).toBe(1.50);
  });
});

describe('GeoFence Validator', () => {
  it('should validate coordinates inside a 200m radius', () => {
    // Vancouver Art Gallery
    const site = { latitude: 49.2827, longitude: -123.1207 };
    // Very close location (e.g. Hotel Georgia across the street)
    const workerInside = { latitude: 49.2831, longitude: -123.1198 };

    const validation = GeoFenceValidator.validate(workerInside, site, 200);
    expect(validation.isWithin).toBe(true);
    expect(validation.distanceMeters).toBeLessThan(200);
  });

  it('should invalidate coordinates outside the radius', () => {
    // Vancouver Art Gallery
    const site = { latitude: 49.2827, longitude: -123.1207 };
    // Stanely Park (approx 2.5km away)
    const workerOutside = { latitude: 49.3017, longitude: -123.1417 };

    const validation = GeoFenceValidator.validate(workerOutside, site, 200);
    expect(validation.isWithin).toBe(false);
    expect(validation.distanceMeters).toBeGreaterThan(200);
  });
});

describe('Dual-Sided Review Engine', () => {
  const authorId = 'client-1';
  const targetId = 'free-1';
  const contractId = 'contract-abc';

  it('should keep review hidden if only one side submits', () => {
    const newReview: ReviewData = {
      id: 'rev-new',
      contractId,
      authorId,
      targetId,
      rating: 5,
      isRevealed: false,
      createdAt: new Date(),
    };

    const existing: ReviewData[] = [];

    const { reviewsToReveal, shouldRevealNew } = ReviewEngine.processReviewSubmission(newReview, existing);

    expect(shouldRevealNew).toBe(false);
    expect(reviewsToReveal).toEqual([]);
  });

  it('should reveal both reviews when counter-party submits', () => {
    const newReview: ReviewData = {
      id: 'rev-freelancer-review-client',
      contractId,
      authorId: targetId, // freelancer is author now
      targetId: authorId,  // target is client
      rating: 4,
      isRevealed: false,
      createdAt: new Date(),
    };

    const existing: ReviewData[] = [
      {
        id: 'rev-client-review-freelancer',
        contractId,
        authorId,         // client is author
        targetId,         // target is freelancer
        rating: 5,
        isRevealed: false,
        createdAt: new Date(Date.now() - 1000 * 60), // 1 min ago
      }
    ];

    const { reviewsToReveal, shouldRevealNew } = ReviewEngine.processReviewSubmission(newReview, existing);

    expect(shouldRevealNew).toBe(true);
    expect(reviewsToReveal).toContain('rev-freelancer-review-client');
    expect(reviewsToReveal).toContain('rev-client-review-freelancer');
  });

  it('should reveal historical review after grace period has elapsed', () => {
    const oldReview: ReviewData = {
      id: 'rev-old',
      contractId,
      authorId,
      targetId,
      rating: 5,
      isRevealed: false,
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000), // 15 days ago (exceeds 14 days)
    };

    const { reviewsToReveal, shouldRevealNew } = ReviewEngine.processReviewSubmission(oldReview, []);

    expect(shouldRevealNew).toBe(true);
    expect(reviewsToReveal).toContain('rev-old');
  });
});
