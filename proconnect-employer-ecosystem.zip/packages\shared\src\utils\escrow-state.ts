export type EscrowState = 'CREATED' | 'FUNDED' | 'RELEASED' | 'DISPUTED' | 'RESOLVED' | 'VOIDED' | 'REFUNDED';

export interface EscrowContext {
  id: string;
  totalAmount: number;
  remainingAmount: number;
  freelancerId: string;
  clientId: string;
  description?: string;
}

export class EscrowStateMachine {
  private state: EscrowState;
  private context: EscrowContext;

  private static transitions: Record<EscrowState, EscrowState[]> = {
    CREATED: ['FUNDED', 'VOIDED'],
    FUNDED: ['RELEASED', 'DISPUTED', 'REFUNDED'],
    RELEASED: [],
    DISPUTED: ['RESOLVED'],
    RESOLVED: [],
    VOIDED: [],
    REFUNDED: [],
  };

  constructor(initialState: EscrowState, context: EscrowContext) {
    this.state = initialState;
    this.context = context;
  }

  public getState(): EscrowState {
    return this.state;
  }

  public getContext(): EscrowContext {
    return this.context;
  }

  /**
   * Check if a transition to a new state is valid.
   */
  public canTransitionTo(nextState: EscrowState): boolean {
    const allowed = EscrowStateMachine.transitions[this.state];
    return allowed.includes(nextState);
  }

  /**
   * Attempt to transition the escrow to a new state.
   */
  public transitionTo(nextState: EscrowState): void {
    if (!this.canTransitionTo(nextState)) {
      throw new Error(`Invalid escrow state transition from ${this.state} to ${nextState}`);
    }
    this.state = nextState;
  }

  /**
   * Release milestones funds. Deducts from remaining amount.
   */
  public releaseFunds(amount: number): void {
    if (this.state !== 'FUNDED') {
      throw new Error('Funds can only be released when the escrow is in FUNDED state.');
    }
    if (amount <= 0) {
      throw new Error('Release amount must be greater than zero.');
    }
    if (amount > this.context.remainingAmount) {
      throw new Error(`Cannot release ${amount}, only ${this.context.remainingAmount} remaining in escrow.`);
    }

    this.context.remainingAmount -= amount;

    if (this.context.remainingAmount === 0) {
      this.transitionTo('RELEASED');
    }
  }

  /**
   * File a dispute.
   */
  public fileDispute(): void {
    this.transitionTo('DISPUTED');
  }

  /**
   * Resolve a dispute with split ratios.
   */
  public resolveDispute(freelancerPayout: number, clientRefund: number): { freelancerPayout: number; clientRefund: number } {
    if (this.state !== 'DISPUTED') {
      throw new Error('Disputes can only be resolved when the escrow is in DISPUTED state.');
    }
    const totalSplit = freelancerPayout + clientRefund;
    // Account for JS floating-point precision
    if (Math.abs(totalSplit - this.context.remainingAmount) > 0.01) {
      throw new Error(`Split sum (${totalSplit}) must equal remaining escrow amount (${this.context.remainingAmount}).`);
    }

    this.context.remainingAmount = 0;
    this.transitionTo('RESOLVED');

    return { freelancerPayout, clientRefund };
  }

  /**
   * Refund the client fully from FUNDED state.
   */
  public refundClient(): void {
    this.transitionTo('REFUNDED');
    this.context.remainingAmount = 0;
  }

  /**
   * Void the contract before funding it.
   */
  public voidContract(): void {
    this.transitionTo('VOIDED');
  }
}
